
document.WidgetList.LoadWidget("WidgetGaugeMeter","./widgets/WidgetGaugeMeter.js");
document.WidgetList.LoadWidget("WidgetTextSwitcher","./widgets/WidgetTextSwitcher.js");
document.WidgetList.LoadWidget("WidgetTextIf","./widgets/WidgetTextIf.js");
document.WidgetList.LoadWidget("WidgetContentIf","./widgets/WidgetContentIf.js");
document.WidgetList.LoadWidget("WidgetHorizontalMeter","./widgets/WidgetHorizontalMeter.js");

